package main

import (
	"fmt"
)

func main() {
	fmt.Printf("Welcome to programming in Go!\n")
}
